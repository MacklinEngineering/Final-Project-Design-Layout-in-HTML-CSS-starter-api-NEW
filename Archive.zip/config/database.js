// config/database.js
module.exports = {

    'url' : 'mongodb+srv://demo:demo@cluster0-92dvh.mongodb.net/test?retryWrites=true', // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot
    'dbName': 'demo'
};
