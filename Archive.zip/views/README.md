# Welcome to the COMMUNAL App! Our app is used for community members to share resources across their communities.

## See a live version here: https://communalapp.netlify.com/index.html
